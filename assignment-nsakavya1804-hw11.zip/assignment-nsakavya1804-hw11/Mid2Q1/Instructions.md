# Question 1 Cars (25 pts)

You are starting work on a automotive React based App. The layout and styling has been done for you.
You are provided with the following files:

* An `index.html`

* A `index.js` file containing the main React App. **This cannot be modified.**

* A `question1.css` CSS file that contains all the CSS for the site. This cannot be modified. 

* A `CarMakes.json` file which contains information about car manufacturers. This **cannot** be modified or imported into your components.

You will deliver to me **two** files that you create:

* A `JapaneseCars.js` React component
* A `AmericanCars.js` React component


These files must implement the functionality described below.

## (a) Create Files and Empty Functional Components (5 pts)

Get your *Parcel.js* build working by:

* Creating the Javascript files mentioned above
* Creating the appropriately name React *functional* components in those files.
* Exporting those components in the appropriate way so that the `index.js` file can import them.

At this point you should have a clean build as shown in the screen shot below.

![Clean Parcel.js build](cleanBuild.png)


## (b) `JapaneseCars` Functionality (15 pts)

You will now give the *Japanese* component the following functionality:

* It returns a `<section>` element containing the following
* An ordered list of Japanese car brands 
* Sorted in alphabetical order
* The information should look like the top half of the screen shot below. No extra styling is allowed.

![App with components](components.png)


## (c) `AmericanCars` Functionality (5 pts)

You will now give the *AmericanCars* component the following functionality:

* It returns a `<section>` element containing the following
* An ordered list of american car brands 
* Sorted in reverse alphabetical order
* The information should look like the bottom half of thescreen shot above. No extra styling is allowed.

