import React from 'react';
import ReactDOM from 'react-dom';


    class JapaneseCars extends React.Component 
{ 
     constructor(props) {
        super(props); }
    render(){
        let list1=props.cars.map(function(val,i){
            return <ol key={"car",+i}>
                <li>{val.make_display}</li>
            <li>{val.make_country}</li></ol>}
            
        });
        let sorted=list.sort(function(a,b){
            if(a.make_display<=b.make_display){
                return -1;
            }
            else{
                return 1;
            }
        });
        
        let list = list1.map(function(val,i){
        return <ol key={"car",+i}>
            <li>{i}.{val.make_display}</li></ol>
    });
    
        let contents = <section>
            <main>
            <section>
            <h1><strong>Automobile Manufacturers</strong></h1>
                <h3><strong>Japanese Brands</strong></h3>
                    {list};
        </section>
        </main>
        </section>;
        
        return <div>{contents}</div>;
        }
    
}
                              
export default JapaneseCars;