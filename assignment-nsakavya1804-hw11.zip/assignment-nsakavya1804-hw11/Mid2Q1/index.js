import React from 'react';
import ReactDOM from 'react-dom';
import cars from './CarMakes.json';
import JapaneseCars from './JapaneseCars';
import AmericanCars from './AmericanCars';

let contents = <div><h1>Automobile Manufacturers</h1>
        <JapaneseCars cars={cars} />
        <AmericanCars cars={cars} />
    </div>;

ReactDOM.render(
  contents,
  document.getElementById('root')
);
