import React from 'react';
import ReactDOM from 'react-dom';

class AnimalSightings extends React.Component(){
    constructor(props) {
        super(props);}
    buttonhandler(event){
        let spotter = document.getElementById("input1");
        let platypus = document.getElementById("input2");
        let kangaroo = document.getElementById("input3");
        let Bennetts  = document.getElementById("input4");
        let Wombat = document.getElementById("input5");
        let Tasmanian = document.getElementById("input6");
       
         let finalstate = this.pops.func.concat({spotter:{spotter.value}, platypus:{ platypus.value},kangaroo:{kangaroo.value}, Bennetts:{ Bennetts.value}, Wombat:{ Wombat.value},Tasmanian:{Tasmanian.value});
       
    }
    render(){
             
        let contents = <div>
            <div id="SightingForm">
                <label>Spotter and location</label>
        <input id="input1" type="text">
               <label>Platypus</label>
        <input id="input2" type="text">
               <label>Forester Kangaroo</label>
        <input id="input3" type="text">
               <label>Bennetts Wallaby</label>
        <input id="input4" type="text">
            <label>Common Wombat</label>
        <input id="input5" type="text">
            <label>Tasmanian Devil</label>
        <input id="input6" type="text">
            <button id="mybutton" onclick={this.buttonhandler.bind(this)}>Register Sighting</button></div>
                <textarea id="spot> </textarea>
        </div>;
        return <div>{contents}</div>;
    }
    
}
export default AnimalSightings;