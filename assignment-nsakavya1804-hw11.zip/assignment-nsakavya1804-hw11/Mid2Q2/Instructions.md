# Question 2 Tasmania (25 pts)

You are starting work on a React based App for tracking animal sightings for the *Tasmania national parks*.  The layout and styling has been done for you. As shown below:

![Tasmania Sightings](components.png)
You are provided with the following files:

* An `index.html` This cannot be modified.

* A `index.js` file containing the main React App. This shows the sighting history on the right side of the App page. You are **only allowed to modify** this file in *two* locations as indicated in coments in the file.

* A `question2.css` CSS file that contains all the CSS for the site. This cannot be modified. 


You will deliver to me **two** files that you create/modify:

* A `AnimalSightings` React component
* An updated `index.js` React App


These files must implement the functionality described below.

## (a) Create Files and Empty  Component (5 pts)

Get your *Parcel.js* build working by:

* Creating the Javascript file mentioned above
* Creating the appropriately named React component in the component file.
* Exporting the component in the appropriate way so that the `index.js` file can import it.

At this point you should have a clean build as shown in the screen shot below.

![Clean Parcel.js build](cleanBuild.png)


## (b) `AnimalSightings` Functionality 1 (10 pts)

You will now give the *AnimalSightings* component, shown on the left side of the top figure, the following functionality:

* It returns a `<div>` element containing the following
* An `<h2>` element containing the form title
* A `<div id="SightingForm">` element that will hold labels, text area, inputs, and button. This will receive grid styling from the style sheet (do not change or add styling).
* A text area for *spotters* information
* At least **two** animal types and inputs 
* A *Register Sighting* button
* ***State*** to keep track of the *sighting* information

## (c) `AnimalSightings` Functionality 2 (10 pts)

You will now give the *AnimalSightings* component, shown on the left side of the top figure, the following additional functionality:

* Changes to all inputs and the text area update the state.
* On the click of *Register Sighting* button you need to add this order to the list of *sightings* kept by the ***App*** in the `index.js` file.
* You are allowed to modify the `index.js` in two places to help you do this.
* Test to make sure that *sightings* are properly added and the latest *sighting* shows up on the right hand side as shown in the figure at the top.

