import React from 'react';
import ReactDOM from 'react-dom';
import AnimalSightings from './AnimalSightings';



class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            sightings: []
        };
        this.functionchange=this.finctionchange.bind(this);
    }
functionchange(change){
    this.setState({sightings:change});
}
    /* YOU ARE ALLOWED TO ADD METHODS STARTING hERE */


    /* END AREA OF PERMITTED ADDED METHODS */

    render() {
        let lastSighting = {};
        let numSightings = this.state.sightings.length;
        if (numSightings > 0) {
            lastSighting = this.state.sightings[numSightings-1];
        }
        return <div id="MainDiv"> 
            <h1> Tasmania National Parks </h1> 
            <AnimalSightings 
                /* CAN ADD CODE STARTING HERE */
                
                /* END  ADDED CODE REGION */
        func={this.functionchange}
            />
            <div>
                <h2>Sightings History</h2>
                <p>Number of Sightings: {this.state.sightings.length}</p>
                <h3>Most Recent Sighting</h3>
                <p>{JSON.stringify(lastSighting, null, 2)}</p>
            </div>
        </div>;
    }
}


ReactDOM.render( < App / > , document.getElementById('root'));
