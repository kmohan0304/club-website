# Homework #11 Solution

**Name: Kavya Mohan**

**NetID: yr9545**

# Question 1

## a) The updated add activity handler is
``` javascript
 addHandler(){
         let x = document.getElementById("name");
        let y = document.getElementById("date");
         let sname=x.value;
         let sdate=y.value;
         
         let finalstate = this.state.activities.concat({addName:sname , addDate:sdate});
         let cred = {
             "name": sname,
             "dates":sdate
         }
         let that=this;
          fetch('/activities', {
                    method: 'POST',
                    headers: {
                        "Content-type": "application/json"
                    },
                    body: JSON.stringify(cred)
                }).then(function(response) {
                    console.log('Request status code: ', response.statusText, response.status, response.type);
              if (response.ok) {
               return response.json(); 
                    } else {
              let info = `Status code: ${response.status}, ${response.statusText}`;
             console.log(response);
             return Promise.reject(info); 
              } 
                }).then((val)=>{
               
                  that.setState({activities:finalstate});
                   that.setState({addName:sname});
                   that.setState({addDate:sdate});
            });
     }
```
## b)![Before](images/1bBefore.png)
## Before activity add

## ![After](images/1bAfter.png)
## After activity add

# Question 2

## a) The updated delete Activity handler is
``` javascript
deleteHandler(index)
    {
        fetch('/activities/aI31pTB5b8tOQpEm', {
                    method: 'DELETE'
                }).then(function(response) {
                    console.log('Request status code: ', response.statusText, response.status, response.type);
                    return response.json();
                }).then((val)=>{
                console.log('Success: val');
                 this.props.deleteRow(index);
                
            }).catch((err)=>{
                console.error('Error:',error);
            });
       
    }
```
## b)![Before](images/1bAfter.png)
## Before activity deletion

## ![After](images/2bAfter.png)
## After activity deletion

# Question 3

## a)Apart from member's firstname, lastname, email and password, the below can be added to the schema.
## 1) ActivityInfo - stating the member's activity number
## 2) Level - is the member a beginner, intermediate or an expert
## 3) Comments - member's comments and other extra information.

## b) The schema is
``` json
{
    "$schema": "http://json-schema.org/draft-07/schema#",
    "$id": "Member.schema.json",
    "title": "Bay Area Club Membership application schema",
    "description": "A Schema for checking the members applications",
    "type": "object",
    "properties": {
        "firstName": {
            "description": "Member's first name",
            "type": "string",
            "minLength":1,
            "maxLength":40
        },
        "lastName": {
            "description": "Member's last name",
            "type": "string",
            "minLength":1,
            "maxLength":40
        },
        "email": {
            "description": "Member's email",
            "type": "string",
            "maxLength":40
        },
        "password": {
            "type": "string",
            "minLength":4,
            "maxLength":40
        },
        "ActivityInfo":{
            "description": "Member's Activity number",
             "type": "string",
            "maxLength":30
        },
        "level":{
             "description": "Member's Activity level",
             "type": "string",
            "enum":["Never Done It","Beginner","Intermediate","Expert"]  
        },
        "comments":{
            "description": "Member's comments or extra information",
            "type": "string",
            "maxLength":1000
        }
    },
    "required": ["firstName", "lastName","email","password","level"],
    "additionalProperties": false
}
```
## c)Good test case
``` json
{"firstName": "Kavya", 
 "lastName":"Mohan",
"email": "kavya@gmail.com",
"password":"12345",
"level":"Beginner",
 "comments":"Amazing club"
}
```
## Bad test case - here String 'This ia a bad first name and bad last name' exceeds maximum length of 40.and Value "Do it" is not defined in enum.
``` json
{"firstName": "Bad name", 
 "lastName":"This ia a bad first name and bad last name",
"email": "bad@bad.com",
"password":"iamabadpassword",
"level":"Do it",
"comments":"Bad comment"
}
```

# Question 4

## a)The /applicants interface is
``` javascript
app.post("/applicants",express.json(),function(req,res){
    let data = req.body;
    var ajv = new Ajv(); 
    var validate = ajv.compile(schema);
    var valid = validate(data);
    if (!valid) {
        res.json(validate.errors);}
    else{
        console.log("success");
        res.json({"message":"received your application"});
    }
});
```

## b)The test code is
``` javascript
const rp = require('request-promise-native');
let goodcase1 ={
    uri:'http://127.63.73.2:1804/applicants',
    method:'POST',
    body: {
     "firstName": "Kavya", 
    "lastName":"Mohan",
    "email": "kavya@gmail.com",
    "password":"12345",
    "level":"Beginner",
    "comments":"Amazing club"
},
   json:true
}

let goodcase2 = {
     uri:'http://127.63.73.2:1804/applicants',
    method:'POST',
    body: {
     "firstName": "Diya", 
    "lastName":"Nayak",
    "email": "diya@gmail.com",
    "password":"12345!",
    "level":"Intermediate",
    "comments":"Nice club"
},
   json:true
}

let badcase1={
      uri:'http://127.63.73.2:1804/applicants',
    method:'POST',
    body:{
        "firstName": "Bad name", 
        "lastName":"This ia a bad first name and bad last name",
        "email": "bad@bad.com",
        "password":"iamabadpassword",
         "level":"Do it",
         "comments":"Bad comment"
    },
      json:true
}
let badcase2={
      uri:'http://127.63.73.2:1804/applicants',
    method:'POST',
    body:{
        "firstName": "44444", 
        "lastName":"This ia a bad first name and bad last name",
        "email": "44444@bad.com",
        "password":"iamabadpassword",
         "level":"bad level",
         "comments":"Bad comment"
    },
      json:true
}

async function schemaTests() {
    console.log("Applicant Test 1: Good #1");
    try{
        let res11 = await rp(goodcase1);
        console.log(`Application results: ${JSON.stringify(res11)}`);
}catch(e){
    console.log(`Error: ${e}`);
}
     console.log("Applicant Test 2: Good #2");
    try{
        let res12 = await rp(goodcase2);
        console.log(`Application results: ${JSON.stringify(res12)}`);
}catch(e){
    console.log(`Error: ${e}`);
}
    console.log("Applicant Test 3: Bad #1");
    try{
        let res13 = await rp(badcase1);
        console.log(`Application results: ${JSON.stringify(res13)}`);
}catch(e){
    console.log(`Error: ${e}`);
}
    console.log("Applicant Test 4: Bad #2");
    try{
        let res14 = await rp(badcase2);
        console.log(`Application results: ${JSON.stringify(res14)}`);
}catch(e){
    console.log(`Error: ${e}`);
}
}
schemaTests();
```

## ![Applicant data testing](images/4b.png)

# Question 5

## a)With web sockets,you can send messages to a server and receive event-driven responses without having to poll the server for a reply.Whereas, in push notifications ,notifications are produced on the screen until and unless the user has subscribed to them. With web sockets there can be multiple clients on the same server but this is not possible with push notifications. There can be a single or broadcaster message chat done with websockets which cannot be done with push notification as tehre is no scope to chat. A service worker needs to be installed in the browser for push notifications to work. The ws websocket library is needed to use the web socket functionality.

## b)WebSockets Protocol Stack
## 1)TCP,IP,Ethernet
## 2)TCP functionality is used to make two way communication.
## 3)Both Text and Binary formats are supported.
## 4)YES, there is a procedure to “upgrade” from HTTP to WebSockets known as the opening Handshake.

## c)WebSockets in the Browser
## 1)Web socket is initiated in the browser side by creatind a websocket by the syntax, myWS = new WebSocket(url[, protocols]).
## 2)There is no limit on the number of web socket connection on the client side unless a manual restriction is made on the browser.
## 3)Yes. By using the websocket event close and with user interface that reports the status of the websocket, it is possible for a client to determine whether a websocket is closed or not.

## d)WebSockets on the Server
## 1)No they are not the same. As HTTP server does not provide two way communication, but websocket server does provide a two way communication. An HTTP(S) Server receives upgrade header to let it know that a WebSocket is desired.But the websocket events are used to control the actions of websocket.
## 2)Express.js works with HTTP server.
## 3)Due to security or authorization reasons that might involve interruption from other clients, there is a need for authorizing a client by having a seperate websocket for each client.

## e)WebSocket Application Design
## 1)yes
## 2)To keep track of the clients and also for aunthetication purpose do that no two clients interuppt into each other.
## 3)With already confirmed clients, server will have to keep track of client's socket to avoid repeated handshakes . If we don't track then the same client IP adress may try to connect multiple times but the server can deny the attempt inorder to save itself from Denial-of-Service attacks.For example, we can keep table of username or ID numbers along with the corresponding websocket and other data we need to associate with the connection.