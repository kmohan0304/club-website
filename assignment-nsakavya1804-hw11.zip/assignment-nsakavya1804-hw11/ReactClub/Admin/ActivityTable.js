import React from 'react';
import ReactDOM from 'react-dom';
import elements from "./activities.json";

class ActivitiyTable extends React.Component 
{ 
     constructor(props) {
        super(props);
         
    }
deleteHandler(index)
    {
        fetch('/activities/aI31pTB5b8tOQpEm', {
                    method: 'DELETE'
                }).then(function(response) {
                    console.log('Request status code: ', response.statusText, response.status, response.type);
                    return response.json();
                }).then((val)=>{
                console.log('Success: val');
                 this.props.deleteRow(index);
                
            }).catch((err)=>{
                console.error('Error:',error);
            });
       
    }
    render(){
    let rows = this.props.activities.map((element,index)=>{
        let tablerow = <tr><td><button onClick={this.deleteHandler.bind(this,index)}>Delete</button></td>
            <td>{element.addName}</td>
        <td>{element.addDate}</td></tr>;
        return tablerow;
    });
        
      
   let contents=<section>     
        <h2><strong>Activities</strong></h2>
<section id = "EventTable">
    <table>
        <thead>
                <tr>
                    <td>  </td>
                    <td><strong>Name</strong></td>
                    <td><strong>Dates</strong></td>
                </tr>
               
            </thead>
         <tbody>{rows}</tbody>
        </table>
    </section>
        </section>;
        return contents;
        
    }}
export default ActivitiyTable;