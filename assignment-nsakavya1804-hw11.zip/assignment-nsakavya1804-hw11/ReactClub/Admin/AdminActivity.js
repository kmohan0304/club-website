import React from 'react';
import ReactDOM from 'react-dom';
import image1 from "./imgs/webimage1.jpg";
import image2 from "./imgs/webimages2.jpg";
import image3 from "./imgs/webimage3.jpg";
import image4 from "./imgs/webimage4.jpg";
import image5 from "./imgs/yoga.jpg";
import image6 from "./imgs/part.jpg";
import ActivityTable from "./ActivityTable";


class AdminActivities extends React.Component 
{ 
     constructor(props) {
        super(props);
          this.state = {activities:[ ],addDate:" ", addName:" "};
         this.removeRow = this.removeRow.bind(this);      
    }
    
     addHandler(){
         let x = document.getElementById("name");
        let y = document.getElementById("date");
         let sname=x.value;
         let sdate=y.value;
         
         let finalstate = this.state.activities.concat({addName:sname , addDate:sdate});
         let cred = {
             "name": sname,
             "dates":sdate
         }
         let that=this;
          fetch('/activities', {
                    method: 'POST',
                    headers: {
                        "Content-type": "application/json"
                    },
                    body: JSON.stringify(cred)
                }).then(function(response) {
                    console.log('Request status code: ', response.statusText, response.status, response.type);
              if (response.ok) {
               return response.json(); 
                    } else {
              let info = `Status code: ${response.status}, ${response.statusText}`;
             console.log(response);
             return Promise.reject(info); 
              } 
                }).then((val)=>{
               
                  that.setState({activities:finalstate});
                   that.setState({addName:sname});
                   that.setState({addDate:sdate});
            });
     }
   
    removeRow(ele){
        let element = this.state.activities.filter((item,z)=> ele!=z);
        this.setState({activities:element});
    }
    
    render(){
     
    let Image1 =<img className="image-activitypage" src={image1} />;
    let Image2 =<img className="image-activitypage" src={image2} />;
    let Image3 =<img className="image-activitypage" src={image3} />;
    let Image4 =<img className="image-activitypage" src={image4} />;
    let Image5 =<img className="image-activitypage" src={image5} />;
    let Image6 =<img className="image-activitypage" src={image6} />;
    
   let adding= <ActivityTable activities={this.state.activities} deleteRow={this.removeRow.bind(this)} />;
    let content= <section>
        <h1>Club Project Club Activities page</h1>    
<main>
            <h1><strong>Activity Management</strong></h1>
    <h2><strong>Add Activity</strong></h2>
    <section id="actadd">
    <p id="loginform"> <label>Name:</label>  
        <input id="name" type="text"  />
      <label>Date:</label> 
       <input id="date" type="text" /> </p>
   <p> <button onClick={this.addHandler.bind(this)}>Add</button></p></section>
        {adding}
</main>
         <p> {Image1} {Image2}  {Image3}  {Image4}  {Image5}  {Image6}  
          </p>
        </section>;
    return <div>{content}</div>;
}
}
export default AdminActivities;