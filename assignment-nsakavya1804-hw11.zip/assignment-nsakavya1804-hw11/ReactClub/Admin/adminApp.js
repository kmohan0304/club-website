import React from 'react';
import ReactDOM from 'react-dom';
import HomeClub from "./clubadmin.js";
import AdminActivities from "./AdminActivity.js";

class AdminApp extends React.Component {
    constructor(props) {
        super(props);
         this.state = {show: "home"};
        this.functionCallbackAdmin=props.functionCallbackAdmin;
    }
    homeHandler(event){
      this.setState({show : "home"});
    }
    AboutHandler(event){
        this.setState({show: "about"});
    }
    ActivitiesHandler(event){
        this.setState({show: "edit-act"});
    }
    MembershipHandler(event){
        this.setSate({show: "membership"});
    }
    LogoutHandler(event){
        const addUrl = 'http://localhost:1235/logout';
            fetch('/logout', {
                    method: 'GET'
                    
                    //body: JSON.stringify(cred)
                }).then(function(response) {
                    //console.log('Request status code: ', response.statusText, response.status, response.type);
                    return response.json();
                }).then((val)=>{
                console.log('Success: val');
                this.functionCallbackAdmin("guest");
                
            }).catch((err)=>{
                console.error('Error:',error);
            });
    }
        
    
    render(){
        let x= <section><nav id="navigation style">
                 <ul>
          <li onClick={this.homeHandler.bind(this)}>Home</li>
          <li onClick={this.AboutHandler.bind(this)}>About</li>
        <li onClick={this.MembershipHandler.bind(this)}>Members Only</li>
            <li onClick={this.ActivitiesHandler.bind(this)}>Edit Activities</li>
         
             <li onClick={this.LogoutHandler.bind(this)}>Logout</li>
            </ul>
           </nav>
         <p><strong>{this.props.name}:{this.props.role}</strong></p>
            </section>;
    let contents = null;
     switch(this.state.show)
         {
        case "home": contents = <HomeClub />;
             break;
         case "about": contents = <About />;
            break;
         case "edit-act": contents = <AdminActivities />;
             break;
        default : contents = <h2>...</h2>;                            
         }
        return <div>{x}{contents}</div>;
}
    }
export default AdminApp;