import React from 'react';
import ReactDOM from 'react-dom';

function About(){
    let content=(
        <section>
    <header>
<h1>Club Project About Page</h1>
</header>
<main id="main style">
<p>Located in the bay area, our club aims to make people's lives better. It offers various activities for all age groups.</p>
</main>
        </section>
    );
    return content;
}
export default About;