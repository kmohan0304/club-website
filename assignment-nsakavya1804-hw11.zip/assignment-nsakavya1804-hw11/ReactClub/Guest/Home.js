import React from 'react';
import ReactDOM from 'react-dom';
import image from "./imgs/homeimage.jpg";

function Home(){
      let nepImage = <img className = "image-homepage" src={image}  alt="The club logo" />;
     let content= (<section>
<header>
 <h1>Club Home Page</h1>
        {nepImage}
</header>
      
<main>
<p>This Club brings you the best in fitness, fun, and relaxation. It can be accessed at all the seasons. It is enabled with indoor and outdoor swimming pools, yoga activities, gym, summer camps, spa, tennis courts, party halls as well as childcare center. </p>
</main>
</section>
                  );
        return content;
}
export default Home;