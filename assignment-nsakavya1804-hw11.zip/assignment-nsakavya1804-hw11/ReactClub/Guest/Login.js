import React from 'react';
import ReactDOM from 'react-dom';

class Login extends React.Component 
{ 
     constructor(props) {
        super(props); }
    
    

    loginHandler(){
        var infoP = document.getElementById("Info");
        let emailx = document.getElementById("email");
        let passwordx = document.getElementById("pass");
        let cred ={
            "email":emailx.value,
            "password":passwordx.value
        };
        /*if(x.value == "admin@email.org")
            {
                 this.props.functionback("admin","Kavya");
            }
         else if(x.value =="member@email.org"){
             this.props.functionback("member","Kavya");
        }
        else if(x.value!="admin@email.org" && x.value !="member@email.org" ){
            this.props.functionback("guest");
        }*/
        
        // here
        let that =this;
        const addUrl = 'http://localhost:1235/login';
            fetch('/login', {
                    method: 'POST',
                    headers: {
                        "Content-type": "application/json"
                    },
                    body: JSON.stringify(cred)
                }).then(function(response) {
                    console.log('Request status code: ', response.statusText, response.status, response.type);
                    return response.json();
               
                }).then((val)=>{
                console.log('Success: ', val.role, val.firstname);
                that.props.functionback(val.role, val.firstname);
                
            });
    }
  render() {
   let content=<section>
        <p id="Info"></p>
         
   <h1>Club Login Page</h1>         
<main>
<p id="heading"><strong>LOGIN</strong> </p>
<p id="loginform"> <label>Email:</label> 
<input id="email" type="email" name="E-mail" />
      <label>Password:</label> 
       <input id="pass" type="password" placeholder="password" /> 
       </p>
    <p><button id ="bt" onClick={this.loginHandler.bind(this)}>Login</button></p>
</main>
       </section>;
    return <div>{content}</div>;
}
}
export default Login;