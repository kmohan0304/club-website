import React from 'react';
import ReactDOM from 'react-dom';
import Home from "./Home.js";
import About from "./About.js";
import Login from "./Login.js";
import Activities from "./activities.js";

class GuestApp extends React.Component {
    constructor(props) {
        super(props);
         this.state = {show: "home"};
    }
    homeHandler(event){
      this.setState({show : "home"});
    }
    AboutHandler(event){
        this.setState({show: "about"});
    }
    ActivitiesHandler(event){
        this.setState({show: "activities"});
    }
    MembershipHandler(event){
        this.setSate({show: "membership"});
    }
    LoginHandler(event){
        this.setState({show: "login"});
    }
   
    render(){
         let x= <section><nav id="navigation style">
               <ul>  
          <li onClick={this.homeHandler.bind(this)}>Home</li>
          <li onClick={this.AboutHandler.bind(this)}>About</li>
            <li onClick={this.ActivitiesHandler.bind(this)}>Activities</li>
         <li onClick={this.MembershipHandler.bind(this)}>Membership</li>
             <li onClick={this.LoginHandler.bind(this)}>Login</li>
        </ul>
           </nav>
            </section>;
    let contents = null;
     switch(this.state.show){
         case "home": contents = <Home />;
             break;
         case "about": contents = <About />;
            break;
         case "activities" : contents = <Activities />;
         break;
         case "login": contents = <Login functionback = {this.props.functionback} />;
             break;
        default : contents = <h2>...</h2>;
           
     }
        return <div>{x}{contents}</div>;
}
    }
export default GuestApp;
