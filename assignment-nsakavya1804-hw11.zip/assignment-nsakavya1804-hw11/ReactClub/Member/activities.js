import React from 'react';
import ReactDOM from 'react-dom';
import elements from "./activities.json";
import image1 from "./imgs/webimage1.jpg";
import image2 from "./imgs/webimages2.jpg";
import image3 from "./imgs/webimage3.jpg";
import image4 from "./imgs/webimage4.jpg";
import image5 from "./imgs/yoga.jpg";
import image6 from "./imgs/part.jpg";


class Activities extends React.Component 
{ 
     constructor(props) {
        super(props);
          this.state = {activities:[ ]};
         
    }
    componentDidMount(){
        let that = this;
        fetch("/activities")
        .then(function(response){
            console.log(
            "Request status code:",
            response.statusText,
            response.type);
            if(response.ok){
                return response.json();
            }else{
                let val = `Status code: ${response.status}, ${response.statusText}`;
                console.log(response);
                return Promise.reject(info);
            }
        }).then(function(activities){
            that.setState({activities:activities});
            console.log(activities);
        }).catch(function(info){
            console.log(info);
        });
        
    }
    
    render(){
        let rows = this.state.activities.map(function(ele){
            return <tr key = {ele.name}>
                <td>{ele.name}</td>
                 <td>{ele.dates}</td>
                 </tr>
        });
    let Image1 =<img className="image-activitypage" src={image1} />;
    let Image2 =<img className="image-activitypage" src={image2} />;
    let Image3 =<img className="image-activitypage" src={image3} />;
    let Image4 =<img className="image-activitypage" src={image4} />;
    let Image5 =<img className="image-activitypage" src={image5} />;
    let Image6 =<img className="image-activitypage" src={image6} />;
   
    let content= <section>
        <h1>Club Project Club Activities page</h1>

    
<main>
<p>We offer various activities like fitness center, swimming classes, yoga, kids camp, parties and events, childcare and many more.</p>
    <section id = "EventTable">
    <table>
        <thead>
                <tr>
                    <td><strong>Event</strong></td>
                    <td><strong>Dates</strong></td>
                </tr>
               
            </thead>
         <tbody>{rows}</tbody>
        </table>
    </section>
</main>
         <p> {Image1} {Image2}  {Image3}  {Image4}  {Image5}  {Image6}  
          </p>
        </section>;
    return <div>{content}</div>;
}
}
export default Activities;