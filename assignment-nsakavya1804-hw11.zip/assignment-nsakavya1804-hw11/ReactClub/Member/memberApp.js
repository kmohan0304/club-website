import React from 'react';
import ReactDOM from 'react-dom';
import HomeClub from "./clubmember.js";
import About from "./MemAbout.js";
import Activities from "./activities.js";

class MemberApp extends React.Component  {
    constructor(props) {
        super(props);
         this.state = {show: "home"};
        this.functionCallbackMember=props.functionCallbackMember;
    }
     homeHandler(event){
      this.setState({show : "home"});
    }
    AboutHandler(event){
        this.setState({show: "about"});
    }
    ActivitiesHandler(event){
        this.setState({show: "activities"});
    }
    MembershipHandler(event){
        this.setState({show: "membership"});
    }
    logoutHandler(event){
        const addUrl = 'http://localhost:1235/logout';
            fetch('/logout', {
                    method: 'GET'
                    
                    //body: JSON.stringify(cred)
                }).then(function(response) {
                    //console.log('Request status code: ', response.statusText, response.status, response.type);
                    return response.json();
                }).then((val)=>{
                console.log('Success: val');
               this.functionCallbackMember("guest");
                
            }).catch((err)=>{
                console.error('Error:',error);
            });
    }
    render(){
    let contents = null;
        let x= <section><nav id="navigation style">
              <ul>   
          <li onClick={this.homeHandler.bind(this)}>Home</li>
          <li onClick={this.AboutHandler.bind(this)}>About</li>
            <li onClick={this.ActivitiesHandler.bind(this)}>Activities</li>
         <li onClick={this.MembershipHandler.bind(this)}>Members Only</li>
             <li onClick={this.logoutHandler.bind(this)}>Logout</li>
            </ul>
           </nav>
        <p><strong>{this.props.name}:{this.props.role}</strong></p>
        
            </section>;
     switch(this.state.show){
         case "home": contents = <HomeClub />;
             break;
         case "about": contents = <About />;
            break;
              case "activities" : contents = <Activities />;
              break;
         case "login": contents = (<section>
           <header>
             <h1>Not Implemented yet</h1>
            </header>
             </section>);
             break;
        default : contents = <h2>...</h2>;
           
     }
        return <div>{x}{contents}</div>;
}
    }
export default MemberApp;


