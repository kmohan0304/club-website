import React from "react";
import ReactDOM from "react-dom";
import Home from "./clubhome.js";
import GuestApp from "./Guest/guestApp.js";
import MemberApp from "./Member/memberApp.js";
import AdminApp from "./Admin/adminApp.js";

class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = {role: "guest", userInfo:""};
        this.functionback = this.functionback.bind(this);
         this.functionCallbackMember = this.functionCallbackMember.bind(this);
         this.functionCallbackAdmin = this.functionCallbackAdmin.bind(this);
      
    }
    functionback(roleData,infouser){
        this.setState({role : roleData});
        this.setState({userInfo: infouser});
    }
     functionCallbackMember(roleData,infouser){
        this.setState({role : roleData});
          this.setState({userInfo :  infouser});
    }
      functionCallbackAdmin(roleData,infouser){
        this.setState({role : roleData});
          this.setState({userInfo : infouser});
    }
    
    render() {
        let contents = null;
     switch(this.state.role){
         case "guest": contents = <GuestApp functionback = {this.functionback} />;
             break;
         case "member": contents = <MemberApp  name={this.state.userInfo}  role={this.state.role} functionCallbackMember = {this.functionCallbackMember} />;
            break;
         case "admin": contents = <AdminApp name={this.state.userInfo}  role={this.state.role} functionCallbackAdmin = {this.functionCallbackAdmin} />;
             break;
        default : contents = <h2>...</h2>;
           
     }
        return <div>{contents}</div>;

    }
}

ReactDOM.render(<App />, document.getElementById("root"));