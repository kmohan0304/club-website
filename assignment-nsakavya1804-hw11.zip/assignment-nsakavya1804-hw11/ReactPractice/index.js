import React from 'react';
import ReactDOM from 'react-dom';
import PeriodicTable from "./periodic.js"
import chemElements from "./elements.json";


let name="Kavya Mohan";
let netID="yr9545";
let cols = ["atomic_number","name","symbol","phase","year_of_discovery"];

const contents = (
  <div>
    <h1>The periodic Table</h1>
    <h2>Brought to you by your {name} and {netID} here</h2>
    <p>There are {chemElements.length} chemical elements</p>
     <PeriodicTable chemElements={chemElements} desiredCols={cols}/>
  </div>
);

ReactDOM.render(
    contents,
  document.getElementById('root')
);


   