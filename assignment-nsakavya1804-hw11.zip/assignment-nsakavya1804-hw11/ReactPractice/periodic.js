import React from 'react';
import ReactDOM from 'react-dom';

function PeriodicTable(properties)
{
    let rows= properties.chemElements.map(function(ele){
        return <tr key={ele.atomic_number}>
        <td>{ele.atomic_number}</td>
        <td>{ele.name}</td>
        <td>{ele.symbol}</td>
        <td>{ele.year_of_discovery}</td>
        </tr>
    });
    let xtable = properties.desiredCols.map((col)=>
                                      <th>{col}</th>
                                      );
    let pTable = <table className="myTable">
        <thead>
        <tr>
        {xtable}
    </tr>
    </thead>
    <tbody>{rows}</tbody>
    </table>;
    return pTable;
}
export default PeriodicTable;