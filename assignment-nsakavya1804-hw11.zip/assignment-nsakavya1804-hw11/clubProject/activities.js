function abc(){
    events.filter(function(value){
                var q = document.getElementById("EventTable").getElementsByTagName("tbody")[0];
                var alphaRow = q.insertRow();
                var alphaCell1 = alphaRow.insertCell(0);
                var alphaText1 = document.createTextNode(value.name);
                alphaCell1.appendChild(alphaText1);
                
                 var alphaCell2 = alphaRow.insertCell(1);
                var alphaText2 = document.createTextNode(value.dates);
                alphaCell2.appendChild(alphaText2);
                
            
            });}

window.onload=abc;