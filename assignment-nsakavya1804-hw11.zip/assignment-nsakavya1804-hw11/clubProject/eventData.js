//club events 2020
events = [{"name":"The Dacing festival",
          "dates":["Febraury 29th","March 4th","March 5th","March 18th","March 24th","April 3rd","May 20th","etc..."]},
         {"name":"Spanish brunch",
          "dates":["Febraury 23rd","March 7th","March 28th","March 30th","April 3rd","April 11th","May 16th","etc..."]},
          {"name":"Kids Magic Show",
          "dates":["March 8th","March 29th","April 5th","April 19th","May 10th","May 31st","etc..."]}
         ];