   function mem()
{
    const modalbtn = document.getElementById("signbt");
           var modal = document.getElementById('ThanksDialog');
            var closebtn = document.getElementById("clbt");
         
          function openThanks(){
              modal.style.display="block";
              var a=document.getElementById("nname");
              var b=document.getElementById("eemail");
              var c=document.getElementById("clubno");
             // var d=document.getElementById("ll");
              var e=document.getElementById("com");
              var thanks=document.getElementById("thanks");
              thanks.innerHTML="Thanks for signing up ";
              var x=document.getElementById("summary");
              x.innerHTML="Name: " +a.value+  ", Email: " +b.value+  ", Club number: " +c.value+  ",  Comments: " +e.value+ ". " ;    
          }
          function cclose1(){
           
              modal.style.display='none';
          }
        
           modalbtn.addEventListener('click',openThanks);
           closebtn.addEventListener('click',cclose1);
                 }
window.onload=mem;
          