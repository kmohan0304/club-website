const DataStore = require('nedb');
const actdb = new DataStore({filename: __dirname + '/newactivityDB', autoload: true});

const act = require('./activities.json');

actdb.insert(act, function(err, newDocs) {
	if(err) {
		console.log("Something went wrong when writing");
		console.log(err);
	} else {
		console.log("Added " + newDocs.length + " activities");
        //console.log(newDocs);
	}
});