const rp = require('request-promise-native');
let cookiejar = rp.jar();

let logout1 = {
     url: 'http://127.63.73.2:1804/logout',
    json: true,
    jar: cookiejar
}
let tourSite = {
    url: 'http://127.63.73.2:1804/activities',
    json: true,
    jar: cookiejar
};
let getcount = {
    url: 'http://127.63.73.2:1804/activities',
     json: true,
    method:"GET",
    jar: cookiejar
}
let addTour = {
    uri: 'http://127.63.73.2:1804/addTour',
    json: true,
    method: "POST",
    body: {
      "name":"Fireless Cooking", "dates":"Only on Sundays"
    },
    jar:  cookiejar
};
let admin1 = {
    uri: 'http://127.63.73.2:1804/login',
    json: true,
    method: "POST",
    body: { 
        "email": "tirrivees1820@outlook.com",
        "password": "49OqspUq"
    },  
    jar:cookiejar
}
let member1 = {
    uri: 'http://127.63.73.2:1804/login',
    json: true,
    method: "POST",
    body: { 
        "email": "chihuahua1899@gmail.com",
        "password": "'E`Gj3iJ"
    },  
    jar:cookiejar
}
let guest1 = {
    uri: 'http://127.63.73.2:1804/login',
    json: true,
    method: "POST",
    body: { 
        "email": "kavya@gmail.com",
        "password": "'iamkavya"
    },  
    jar:cookiejar
    
}

async function someLoginTests() {
    console.log("Add Activity Test 1 : Admin Login");
     try{
        let res11 = await rp(admin1);
         console.log(`login results: ${JSON.stringify(res11)}`);
        console.log(`Admin Login, Cookies: ${cookiejar.getCookieString(admin1.uri)}`);
     } catch(e){
    console.log(`Error: ${e}`);
     }
    try{
        let res12 = await rp(getcount);
        console.log(`Number of activities ${res12.length}`);
    }catch(e){
    console.log(`Error: ${e}`);
     }
    try{
         let res3 = await rp(addTour);
        console.log(`After adding number of activities:  ${res3.length}\n`);
         console.log(`Admin after adding, Cookies: ${cookiejar.getCookieString(addTour.uri)}`);
    }
     catch(e){
    console.log(`Error: ${e}`);
     }
     try{
        let res11 = await rp(logout1);
    console.log(`After Logout, Cookies: ${cookiejar.getCookieString(logout1.url)}`);
     } catch(e){
    console.log(`Error: ${e}`);
     }
    
    ///////////////////////////////////////////////////////
    
    console.log("Add Activity Test 2 : Member Login");
     try{
        let res13 = await rp(member1);
         console.log(`login results: ${JSON.stringify(res13)}`);
        console.log(`Member Login, Cookies: ${cookiejar.getCookieString(member1.uri)}`);
     } catch(e){
    console.log(`Error: ${e}`);
     }
    try{
        let res14 = await rp(getcount);
        console.log(`Number of activities ${res14.length}`);
    }catch(e){
    console.log(`Error: ${e}`);
     }
    try{
         let res15 = await rp(addTour);
        console.log(`After adding number of activities:  ${res15.length}\n`);
         console.log(`Member Login, Cookies: ${cookiejar.getCookieString(addTour.uri)}`);
    }
     catch(e){
    console.log(`Member add activity Error: ${e}`);
     }
     try{
        let res16 = await rp(getcount);
        console.log(`Number of activities ${res16.length}`);
    }catch(e){
    console.log(`Error: ${e}`);
     }
    try{
        let res17 = await rp(member1);
         
        console.log(`After test 2, Cookies: ${cookiejar.getCookieString(member1.uri)}`);
     } catch(e){
    console.log(`Error: ${e}`);
     }
     try{
        let res11 = await rp(logout1);
    console.log(`After Logout, Cookies: ${cookiejar.getCookieString(logout1.url)}`);
     } catch(e){
    console.log(`Error: ${e}`);
     }
    
    
    /////////////////////////////////////////////
     console.log("Add Activity Test 3 : Guest Login");
     try{
        let res19 = await rp(getcount);
        console.log(`Number of activities ${res19.length}`);
    }catch(e){
    console.log(`Error: ${e}`);
     }
    
   
    try{
         let res20 = await rp(addTour);
        console.log(`After adding number of activities:  ${res20.length}\n`);
         console.log(`Guest Login, Cookies: ${cookiejar.getCookieString(addTour.uri)}`);
    }
     catch(e){
    console.log(` Error: ${e}`);
     }
    try{
        let res21 = await rp(tourSite);
        console.log(`After adding Activity test 3, Cookies: ${cookiejar.getCookieString(guest1.uri)}`);
    }
    catch(e){
    console.log(`Test 3 add activity Error: ${e}`);
     }
      
}
someLoginTests();














