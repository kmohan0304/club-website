const rp = require('request-promise-native');
let goodcase1 ={
    uri:'http://127.63.73.2:1804/applicants',
    method:'POST',
    body: {
     "firstName": "Kavya", 
    "lastName":"Mohan",
    "email": "kavya@gmail.com",
    "password":"12345",
    "level":"Beginner",
    "comments":"Amazing club"
},
   json:true
}

let goodcase2 = {
     uri:'http://127.63.73.2:1804/applicants',
    method:'POST',
    body: {
     "firstName": "Diya", 
    "lastName":"Nayak",
    "email": "diya@gmail.com",
    "password":"12345!",
    "level":"Intermediate",
    "comments":"Nice club"
},
   json:true
}

let badcase1={
      uri:'http://127.63.73.2:1804/applicants',
    method:'POST',
    body:{
        "firstName": "Bad name", 
        "lastName":"This ia a bad first name and bad last name",
        "email": "bad@bad.com",
        "password":"iamabadpassword",
         "level":"Do it",
         "comments":"Bad comment"
    },
      json:true
}
let badcase2={
      uri:'http://127.63.73.2:1804/applicants',
    method:'POST',
    body:{
        "firstName": "44444", 
        "lastName":"This ia a bad first name and bad last name",
        "email": "44444@bad.com",
        "password":"iamabadpassword",
         "level":"bad level",
         "comments":"Bad comment"
    },
      json:true
}

async function schemaTests() {
    console.log("Applicant Test 1: Good #1");
    try{
        let res11 = await rp(goodcase1);
        console.log(`Application results: ${JSON.stringify(res11)}`);
}catch(e){
    console.log(`Error: ${e}`);
}
     console.log("Applicant Test 2: Good #2");
    try{
        let res12 = await rp(goodcase2);
        console.log(`Application results: ${JSON.stringify(res12)}`);
}catch(e){
    console.log(`Error: ${e}`);
}
    console.log("Applicant Test 3: Bad #1");
    try{
        let res13 = await rp(badcase1);
        console.log(`Application results: ${JSON.stringify(res13)}`);
}catch(e){
    console.log(`Error: ${e}`);
}
    console.log("Applicant Test 4: Bad #2");
    try{
        let res14 = await rp(badcase2);
        console.log(`Application results: ${JSON.stringify(res14)}`);
}catch(e){
    console.log(`Error: ${e}`);
}
}
schemaTests();