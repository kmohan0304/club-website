const fs = require('fs');
const bcrypt = require('bcryptjs');
const users = require('./clubUsers2.json');
let nRounds = 13;
let hashedUsers = [];
let start = new Date(); 
console.log(`Starting password hashing with nRounds = ${nRounds}, ${start}`);
let salt = bcrypt.genSaltSync(10);
let passHash = users.map(function(val,i){
    var hashed=bcrypt.hashSync(val.password, salt);
    var x = {"firstname":val.firstName, "lastName":val.lastName, "email":val.email, "password":hashed, "role":val.role};
    return x;
});
hashedUsers.push(passHash);
let elapsed = new Date() - start; 
console.log(`Finished password hashing, ${elapsed/1000} seconds.`);
fs.writeFileSync("clubUsersHash.json", JSON.stringify(hashedUsers, null, 2));





