var express = require('express');
var app = express();
const session = require('express-session');
const activities = require("./activities.json");
const ACT_LIMIT = 500;
const bcrypt = require('bcryptjs');
const users = require('./clubUsersHash.json');
const DataStore = require('nedb');
const actdb = new DataStore({filename: __dirname + '/newactivityDB', autoload: true});
var Ajv = require('ajv');
var schema = require('./memberschema.json');

app.get('/activities',function(req,res){
    actdb.find({},function(err,docs){
        if(err){
            console.log("Something is wrong");
        }
        else{
            res.json(docs);
        }
    });
});
function activityErrors(err,req,res,next){
    res.status(400).json({
        error:true,
        message:"bad activity"
    });
    console.log(JSON.stringfy(err));
    return;
}
app.post("/activities",express.json({limit:ACT_LIMIT} ),function(req,res){
        let activity = req.body;
    console.log(`${JSON.stringify(activity)}`);
    actdb.insert(activity, function(err, newDocs) {
    if(err) {
        console.log("Something went wrong when writing");
        console.log(err);
    } else {
        //res.json(docs);
         res.json(newDocs);
    }
});
   // activities.push(activity);
   // res.json(newDocs);
    },
        activityErrors
        );
app.post("/applicants",express.json(),function(req,res){
    let data = req.body;
    var ajv = new Ajv(); 
    var validate = ajv.compile(schema);
    var valid = validate(data);
    if (!valid) {
        res.json({"Error":"true","message":validate.errors});}
       
    else{
        console.log("success");
        res.json({"message":"received your application"});
    }
});

app.delete("/activities/indexID",express.json(),function(req,res){
    let index = req.params.indexID;
    console.log(`Trying to delete activity ${index}`);

      actdb.remove({_id:index});
       actdb.find({},function(err,docs){
        if(err){
            console.log("Something is wrong");
        }
        else{
            res.json(docs);
        }
    }) ;
    /*if(index<0 || index >= activities.length){
        console.log(`Bad activity deletion index: ${index}`);
        res.status(400).json({error:true,message:"Bad index"});
        return;
    }*/
  
    //activities.splice(index,1);
   
});

const cookieName = "yr9545"; 
app.use(session({
    secret: 'Kavya Mohan',
    resave: false,
    saveUninitialized: false,
    name: cookieName // Sets the name of the cookie used by the session middleware
}));

const setUpSessionMiddleware = function (req, res, next) {
    console.log(`session object: ${JSON.stringify(req.session)}`);
    console.log(`session id: ${req.session.id}`);
    if (!req.session.user) {
        req.session.user = {role: "guest"};
    };
    next();
};

app.use(setUpSessionMiddleware);


const checkAdminMiddleware = function (req, res, next) {
    if (req.session.user.role !== "admin") {
        res.status(401).json({error: "Not permitted"});
    } else {
        next();
    }
};
// Only available to admin, returns updated tour list.
app.post('/addTour', checkAdminMiddleware, express.json(), function (req, res) {
    let temp = req.body;
    console.log(temp);
    // Note need to check input here to prevent injection attacks
    let event = {
        name: temp.name,
        dates: temp.dates,
    };
    activities.push(event);
    res.json(activities);
});

app.get('/userInformation',checkAdminMiddleware, express.json(), function (req, res){
   /* let userinfo = users;
    delete userinfo.password;
     res.json(userinfo);  
    console.log(userinfo);*/
    let passHash = users.map(function(val,i){
    var x = {"firstname":val.firstname, "lastName":val.lastName, "email":val.email, "role":val.role};
    return x;
});
    res.json(passHash);
});


app.post('/login', express.json(), function (req, res) {
    console.log(req.body);
    let email = req.body.email;
    let password = req.body.password;
    let resultuser = users.find(function (user) {
        return user.email === email
    });
    if (!resultuser) {
        res.status(401).json({error: true, message: "User/Password error"});
        return;
    }
    let verified = bcrypt.compareSync(password, resultuser.password);
    if(verified){
        /* let newUserInfo= resultuser;
            delete newUserInfo.password;
         res.json(newUserInfo);*/
          let oldInfo = req.session.user;
        req.session.regenerate(function (err) {
           if (err) {console.log(err);}
            let newUserInfo = Object.assign(oldInfo, resultuser);
       delete newUserInfo.password;
           req.session.user = newUserInfo;
            res.json(newUserInfo);
        });
    }
    else{
       res.status(401).json({error: true, message: "User/Password error"});
    }
});

app.get('/logout', function (req, res) {
    let options = req.session.cookie;
    req.session.destroy(function (err) {
        if (err) {
            console.log(err);
        }
        res.clearCookie(cookieName, options); // the cookie name and options
        res.json({message: "Goodbye"});
    })
});



host = '127.63.73.2';
port = '1804';
app.listen(port,host,function(){
    console.log(`clubserver.js app is listening on IPv4 : ${host} :${port}`);
});

    
