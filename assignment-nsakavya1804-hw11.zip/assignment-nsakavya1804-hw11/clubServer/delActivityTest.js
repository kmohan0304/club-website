const DataStore = require('nedb');
const actdb = new DataStore({filename: __dirname + '/newactivityDB', autoload: true});
const request = require('request-promise-native');
const x = false;
let first = {
    uri:'http://127.63.73.2:1804/activities',
    method:'GET',
    json:true
};
let goodD = {
    uri:'http://127.63.73.2:1804/activities/RBFRsqSYzhaAFrCc',
    method:'DELETE',
    json:true,
};
let badD = {
    uri:'http://127.63.73.2:1804/activities/o3NqVfKEuv3zYdSG',
    method:'DELETE',
    json:true,
};
let goodD2 = {
    uri:'http://127.63.73.2:1804/activities/ofY3mbbhyWibyIBr',
    method:'DELETE',
    json:true,
};
function outputPrint(val){
    console.log(`Currently  ${val.length} activities`);
    if(!x){
        return;
    }
    val.forEach(function(activity,index){
        console.log(`Activity ${index+1} name${activity.name} date:${activity.dates}`);
    });
}
request(first).then(function(val){
    console.log("Initial Get of Activities");
    outputPrint(val);
    return request(goodD);
}).then(function(val){
    console.log("After first good Activity deletion");
    outputPrint(val);
    return request(badD);
}).then(function(val){
    outputPrint(val);
    return request(goodD2);
}).catch(function(error){
    console.log(`After first bad Activity delete`);
    console.log(`Error:${error}`);
    return request(goodD2);
}).then(function(val){
    console.log("After another good Activity delete");
       outputPrint(val);
});

