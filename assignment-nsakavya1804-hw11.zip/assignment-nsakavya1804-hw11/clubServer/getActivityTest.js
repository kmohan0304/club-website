const reqpro = require('request-promise-native');
let choice = {
    uri:'http://127.63.73.2:1804/activities',
    json:true
};
reqpro(choice).then(function(val){
    val.forEach(function(activity,i){
        console.log(`Activity ${i+1} name:${activity.name}, date:${activity.dates}${activity._id}`);
    });
}).catch(function(error){
    console.log(`Error:${error}`);
})