const rp = require('request-promise-native');
let cookiejar = rp.jar();
let logout1 = {
     url: 'http://127.63.73.2:1804/logout',
    json: true,
    jar: cookiejar
}
let getcount = {
    url: 'http://127.63.73.2:1804/userInformation',
     json: true,
    method:"GET",
    jar: cookiejar
}
let admin1 = {
    uri: 'http://127.63.73.2:1804/login',
    json: true,
    method: "POST",
    body: { 
        "email": "tirrivees1820@outlook.com",
        "password": "49OqspUq"
    },  
    jar:cookiejar
}
let member1 = {
    uri: 'http://127.63.73.2:1804/login',
    json: true,
    method: "POST",
    body: { 
        "email": "chihuahua1899@gmail.com",
        "password": "'E`Gj3iJ"
    },  
    jar:cookiejar
}
let guest1 = {
    uri: 'http://127.63.73.2:1804/login',
    json: true,
    method: "POST",
    body: { 
        "email": "kavya@gmail.com",
        "password": "'iamkavya"
    },  
    jar:cookiejar
    
}
async function someLoginTests() {
    console.log("Get User Test 1 : Admin Login");
     try{
        let res1 = await rp(admin1);
        console.log(`Admin Login, Cookies: ${cookiejar.getCookieString(admin1.uri)}`);
     } catch(e){
    console.log(`Error: ${e}`);
     }
    try{
        let res2 = await rp(getcount);
        console.log(`Number of users :${res2.length}`);
    }catch(e){
    console.log(`Error: ${e}`);
     }
    try{
        let res3 = await rp(logout1);
    console.log(`After Logout, Cookies: ${cookiejar.getCookieString(logout1.url)}`);
     } catch(e){
    console.log(`Error: ${e}`);
     }
    
    console.log("Get User Test 2 : Member Login");
     try{
        let res1 = await rp(member1);
        console.log(`Member Login, Cookies: ${cookiejar.getCookieString(member1.uri)}`);
     } catch(e){
    console.log(`Error: ${e}`);
     }
    try{
        let res2 = await rp(getcount);
        console.log(`Number of users :${res2.length}`);
    }catch(e){
    console.log(`Member is getting user Error: ${e}`);
     }
    try{
        let res3 = await rp(logout1);
    console.log(`After Logout, Cookies: ${cookiejar.getCookieString(logout1.url)}`);
     } catch(e){
    console.log(`Error: ${e}`);
     }
    
    console.log("Get User Test 3 : Guest");
     
    try{
        let res2 = await rp(getcount);
        console.log(`Number of users :${res2.length}`);
    }catch(e){
    console.log(`Guest is getting user Error: ${e}`);
     } 
    try{
       
        console.log(`Member Login, Cookies: ${cookiejar.getCookieString(guest1.uri)}`);
     } catch(e){
    console.log(`Error: ${e}`);
     }
}
someLoginTests();