const rp = require('request-promise-native');
const cookieJar = rp.jar();
let tourSite = {
    url: 'http://127.63.73.2:1804/activities',
    json: true,
    jar: cookieJar
};
let logout1 = {
     url: 'http://127.63.73.2:1804/logout',
    json: true,
    jar: cookieJar
}

let GoodEmailandPassword = {
    url: 'http://127.63.73.2:1804/login',
    json: true,
    method: "POST",
    body: { 
        "email": "tirrivees1820@outlook.com",
        "password": "49OqspUq"
    },  
    jar:cookieJar
}
let GoodEmailandIncorrectPassword = {
    url: 'http://127.63.73.2:1804/login',
    json: true,
    method: "POST",
    body: { 
        "email":  "umbrate1989@yahoo.com",
        "password": "nMQs)5Vikkk"
    },
 jar:cookieJar
}

let BadEmail = {
    url: 'http://127.63.73.2:1804/login',
    json: true,
    method: "POST",
    body: { 
        "email": "stedhorses1903@yahoo.com",
        "password": "nMQs)5Vi"
    },
     jar:cookieJar
}
async function someLoginTests() {
    console.log("Login Test1:Good Login");
    //console.log("Called Activities, Cookies : ");
    try{
        let res11 = await rp(tourSite);
    console.log(`Called Activities, Cookies: ${cookieJar.getCookieString(tourSite.url)}`);
     } catch(e){
    console.log(`Error: ${e}`);
     }
    console.log("Good Login Test Result");
    try {
        let res2 = await rp(GoodEmailandPassword);
        console.log(`login results: ${JSON.stringify(res2)}`);
        console.log(`After Good Login, Cookies: ${cookieJar.getCookieString(GoodEmailandPassword.url)}`);
    } catch (e) {
        console.log(`Error: ${e}\n`);
    }
    //console.log("After Good Login, Cookies: ");
    /*try{
        //let res111 = await rp(GoodEmailandPassword);
    console.log(`After Good Login, Cookies: ${cookieJar.getCookieString(GoodEmailandPassword.uri)}`);
     } catch(e){
    console.log(`Error: ${e}`);
     }*/
    //console.log("After Logout, Cookies:");
     try{
        let res13 = await rp(logout1);
    console.log(`After Logout, Cookies: ${cookieJar.getCookieString(logout1.url)}\n`);
     } catch(e){
    console.log(`Error: ${e}`);
     }
    
     console.log("Login Test2:Bad Email");
   // console.log("Called Activities, Cookies : ");
    try{
        let res12 = await rp(tourSite);
    console.log(`Called Activities, Cookies : ${cookieJar.getCookieString(tourSite.url)}`);
     } catch(e){
    console.log(`Error: ${e}`);
     }
       console.log("Bad Email Login error");
    try {
        let res3 = await rp( BadEmail);
        console.log(`login results: ${JSON.stringify(res3)}`);
    } catch (e) {
        console.log(`Error: ${e}`);
    }
     // console.log("After Good Login Test 2, Cookies: ");
    try{
       // let res14 = await rp(BadEmail);
    console.log(`After Login Test 2, Cookies: ${cookieJar.getCookieString(BadEmail.url)}\n`);
     } catch(e){
    console.log(`Error: ${e}`);
     }
    
     console.log("Login Test3:Bad Password");
     try{
        let res15 = await rp(tourSite);
    console.log(`Called Activities, Cookies : ${cookieJar.getCookieString(tourSite.url)}`);
     } catch(e){
    console.log(`Error: ${e}`);
     }
    console.log("Bad Password Login Error");
    try {
        let res4 = await rp(GoodEmailandIncorrectPassword);
        console.log(`login results: ${JSON.stringify(res4)}`);
    } catch (e) {
        console.log(`Error: ${e}`);
    }
     //console.log("After Good Login Test 3, Cookies: ");
    try{
        //let res16 = await rp(GoodEmailandIncorrectPassword);
    console.log(`After Login Test 3, Cookies: ${cookieJar.getCookieString(GoodEmailandIncorrectPassword.url)}`);
     } catch(e){
    console.log(`Error: ${e}`);
     }
}
someLoginTests();