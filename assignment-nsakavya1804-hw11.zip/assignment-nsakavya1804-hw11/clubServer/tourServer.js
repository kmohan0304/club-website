const express = require('express');
const app = express();
const session = require('express-session');
const bcrypt = require('bcryptjs');

const cookieName = "TourSid"; // Session ID cookie name, use this to delete cookies too.
app.use(session({
    secret: 'website development CSUEB',
    resave: false,
    saveUninitialized: false,
    name: cookieName // Sets the name of the cookie used by the session middleware
}));

// Fake user and tour data
//const users = require('./clubUsersHash.json');
//const tours = require('./tours.json');
// This initializes session state
const setUpSessionMiddleware = function (req, res, next) {
    console.log(`session object: ${JSON.stringify(req.session)}`);
    console.log(`session id: ${req.session.id}`);
    if (!req.session.user) {
        req.session.user = {role: "guest"};
    };
    next();
};

app.use(setUpSessionMiddleware);
// Use this middleware to restrict paths to only logged in users
/*const checkCustomerMiddleware = function (req, res, next) {
    if (req.session.user.role === "guest") {
        res.status(401).json({error: "Not permitted"});
        } else {
        console.log(`Session info: ${JSON.stringify(req.session)} \n`);
        next();
    }
};*/
// User this middlewave to restrict paths only to admins
/*const checkAdminMiddleware = function (req, res, next) {
    if (req.session.user.role !== "admin") {
        res.status(401).json({error: "Not permitted"});
    } else {
        next();
    }
};*/
// Only available to admin, returns updated tour list.
/*app.post('/addTour', checkAdminMiddleware, express.json(), function (req, res) {
    let temp = req.body;
    console.log(temp);
    // Note need to check input here to prevent injection attacks
    let event = {
        name: temp.name,
        date: temp.date,
    };
    tours.virtTours.push(event);
    res.json(tours.virtTours);
});*/
app.get('/logout', function (req, res) {
    let options = req.session.cookie;
    req.session.destroy(function (err) {
        if (err) {
            console.log(err);
        }
        res.clearCookie(cookieName, options); // the cookie name and options
        res.json({message: "Goodbye"});
    })
});
// Available to all visitors, returns user info if successful
app.post('/login', express.json(), function (req, res) {
    console.log(req.body);
    let email = req.body.email;
    let password = req.body.password;
    // Find user
    let auser = users.find(function (user) {
        return user.email === email
    });
    if (!auser) {// Not found
        res.status(401).json({error: true, message: "User/Password error"});
        return;
    }
    let verified = bcrypt.compareSync(password, auser.passHash);
    if (verified) {
        //Upgrade in priveledge, should generate new session id
        // Save old session information if any, create a new session
        let oldInfo = req.session.user;
        req.session.regenerate(function (err) {
            if (err) {console.log(err);}
            let newUserInfo = Object.assign(oldInfo, auser);
            delete newUserInfo.passHash;
            req.session.user = newUserInfo;
            res.json(newUserInfo);
        });
    } else {
        res.status(401).json({error: true, message: "User/Password error"});
    }
    
});
host = '127.63.73.1';
port = '1804';
app.listen(port,host,function(){
    console.log(`tourserver.js app is listening on IPv4 : ${host} :${port}`);
});
