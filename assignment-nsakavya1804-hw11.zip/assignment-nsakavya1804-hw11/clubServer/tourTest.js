/* Testing the POST /tours/add API */
const rp = require('request-promise-native');

let cookiejar = rp.jar(); // Use this to store cookies in between sessions.

/*let addTour = {
    uri: 'http://127.0.0.1:3434/addTour',
    json: true,
    method: "POST",
    body: {
        name: "Windsurf K2-18b, 110 Light Years",
        date: "Sometime in 2025"
    },
    jar: true
};*/

let GoodEmailandPassword = {
    uri: 'http://127.63.73.2:1804/login',
    json: true,
    method: "POST",
    body: { // admin user, see users.json file
        "email": "tirrivees1820@outlook.com",
        "password": "49OqspUq"
    }
    
}
let GoodEmailandIncorrectPassword = {
    uri: 'http://127.63.73.2:1804/login',
    json: true,
    method: "POST",
    body: { // admin user, see users.json file
        "email":  "umbrate1989@yahoo.com",
        "password": "nMQs)5Vikkk"
    }

}

let BadEmail = {
    uri: 'http://127.63.73.2:1804/login',
    json: true,
    method: "POST",
    body: { // admin user, see users.json file
        "email": "stedhorses1903@yahoo.com",
        "password": "nMQs)5Vi"
    }
}

async function someTests() {
    console.log("Try adding tour without logging in");
   /* try {
        let res1 = await rp(addTour);
        console.log(`Add Tour result: ${JSON.stringify(response)}`);
    } catch (e) {
        console.log(`Error: ${e}\n`);
    }*/

    console.log("Good Login Test Result")
    try {
        let res2 = await rp(GoodEmailandPassword);
        console.log(`login results: ${JSON.stringify(res2)}`);
        //console.log(`Cookie: ${JSON.stringify(cookiejar.cookies)}`);
       // let res3 = await rp(addTour);
       // console.log(`Add Tour result: ${JSON.stringify(res3)}\n`);
    } catch (e) {
        console.log(`Error: ${e}\n`);
    }
       console.log("Bad Login Test Result")
    try {
        let res2 = await rp( BadEmail);
        console.log(`login results: ${JSON.stringify(res2)}`);
        //console.log(`Cookie: ${JSON.stringify(cookiejar.cookies)}`);
       // let res3 = await rp(addTour);
       // console.log(`Add Tour result: ${JSON.stringify(res3)}\n`);
    } catch (e) {
        console.log(`Error: ${e}\n`);
    }
    console.log("Bad Login Test Result")
    try {
        let res4 = await rp(GoodEmailandIncorrectPassword);
        console.log(`login results: ${JSON.stringify(res4)}`);
        //console.log(`Cookie: ${JSON.stringify(cookiejar.cookies)}`);
       // let res5 = await rp(addTour);
        //console.log(`Add Tour result: ${JSON.stringify(res5)}\n`);
    } catch (e) {
        console.log(`Error: ${e}\n`);
    }
}

someTests();