import commonmark from "commonmark";
import hljs from "highlight.js";
import "highlight.js/styles/idea.css";
   

function abc(){
    var renderbt=document.getElementById("renbt");
    
    function rendered(){
        
         var input_m=document.getElementById("input");
        var output_m=document.getElementById("ren");
        var reader = new commonmark.Parser();
        var writer = new commonmark.HtmlRenderer();
        var parsed = reader.parse(input_m.value);
        var res = writer.render(parsed);
        output_m.innerHTML=res;
        output_m.querySelectorAll('pre code').forEach((block)=>{
                                                      hljs.highlightBlock(block);
                                                      });
    }
    renderbt.addEventListener("click",rendered);
    
}
window.onload=abc;