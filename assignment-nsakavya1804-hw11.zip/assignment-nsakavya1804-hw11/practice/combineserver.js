var express = require('express');
var app = express();
app.get('/date',function(req,res){
    res.send(`The current Date and Time is : ${new Date()},Name: Kavya Mohan, NetId: yr9545`);
});
host = '127.63.73.2';
port = '0418';
app.listen(port,host,function(){
    console.log(`netIDserver.js app is listening on IPv4 : ${host} :${port}`);
});