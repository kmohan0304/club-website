var express = require('express');
var app = express();
app.get('/date',function(req,res){
    res.send(`My name is Kavya. The current Date and Time is : ${new Date()}`);
});
host = '127.63.73.2';
port = '4444';
//path = '/date';
app.listen(port,host,function(){
    console.log(`Dateserver.js app is listening on IPv4 : ${host} :${port}`);
});